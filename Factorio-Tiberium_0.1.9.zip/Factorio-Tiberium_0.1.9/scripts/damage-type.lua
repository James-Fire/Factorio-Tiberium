data:extend(
{
  {
    type = "damage-type",
    name = "tiberium"
  }
}
)
