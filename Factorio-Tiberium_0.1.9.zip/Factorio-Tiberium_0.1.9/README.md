# Factorio-Tiberium
The tiberium mod for Factorio  
Currently being updated and expanded.

Credits for the foundation we're building on:  
  The Tiberium mod by Zillo7  
  Which was updated and maintained by sah4001 (updated to 0.16) and Oktabyte (updated to 0.17)  


  Command and Conquer Style Defences by Hexicube  
  Who graciously let us adapt and use the 'hardlight walls' code for implementing the Sonic Repulsion Field fences.
